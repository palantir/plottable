var barData = [
  {category: "A", value: 2},
  {category: "B", value: 5},
  {category: "C", value: 8},
  {category: "D", value: -1},
  {category: "E", value: 3}
];
