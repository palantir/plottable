//population, in millions
wordWrapData = [
	{
		y: "China",
		x: 1365
	},
	{
		y: "The Republic of India",
		x: 1237
	},
	{
		y: "United States of America",
		x: 313
	},	
	{
		y: "Indonesia",
		x: 247
	},
	{
		y: "Brazil",
		x: 199
	}			
];