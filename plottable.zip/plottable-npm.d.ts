import * as Plottable from "./build/src";

export = Plottable;
