import * as Plottable from "./build/src";

export = Plottable;
export as namespace Plottable;
