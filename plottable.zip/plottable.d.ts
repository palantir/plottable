import * as Plottable from "./plottable-npm";

export = Plottable;
export as namespace Plottable;
